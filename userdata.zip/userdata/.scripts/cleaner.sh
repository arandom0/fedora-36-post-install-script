#!/bin/bash

printf "************************\nREMOVING:\n************************\n"
[ -d "$HOME/.cache/sessions/" ] && echo "Thunar Sessions" && rm -r "$HOME/.cache/sessions/"* &>/dev/null
echo "System Thumbnails" && rm -r "$HOME/.cache/thumbnails/"* &>/dev/null
[ -d "$HOME/.var/app/org.kde.gwenview/" ] && echo "Gwenview Flatpak" && rm -r "$HOME/.var/app/org.kde.gwenview/cache/"* &>/dev/null
[ -d "$HOME/.config/xnviewmp/" ] && echo "XnViewMP thumbs and history" && rm "$HOME/.config/xnviewmp/Thumb.db" "$HOME/.config/xnviewmp/XnView.db" &>/dev/null
[ -d "$HOME/.xdman/" ] && echo "XDM History" && rm -r "$HOME/.xdman/metadata/"* "$HOME/.xdman/temp/"* "$HOME/.xdman/downloads.txt" "$HOME/.xdman/queues.txt" &>/dev/null
[ -d "$HOME/.var/app/org.videolan.VLC/" ] && echo "VLC Flatpak" && rm -r "$HOME/.var/app/org.videolan.VLC/cache/vlc/"* &>/dev/null
 [ -d "$HOME/.cache/clipboard-indicator@tudmotu.com/" ] && echo "GNOME Clipboard Extension" && rm -r "$HOME/.cache/clipboard-indicator@tudmotu.com/"* &>/dev/null
read hold
