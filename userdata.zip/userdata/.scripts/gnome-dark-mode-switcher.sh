#!/bin/bash

while [ 1 -eq 1 ]; do
    echo "Press 1 for light theme, 2 for dark theme, and hit enter";
    read userInput;
    userInput=$(echo "$userInput" | xargs); # trim
    
    if [ "$userInput" -eq "1" ]; then
        g42Theme="prefer-light"; gtkTheme="Adwaita";
        gearyDarkModeCss="";
    elif [ "$userInput" -eq "2" ]; then
        g42Theme="prefer-dark"; gtkTheme="Adwaita-dark";
        gearyDarkModeCss=':root, *:not(a) {color: #eeeeec !important; background-color: #353535 !important;}';
    else 
        clear;
        echo "Invalid input, try again";
        continue;
    fi
    
    gsettings set org.gnome.desktop.interface color-scheme "$g42Theme" > /dev/null 2>&1;
    gsettings set org.gnome.desktop.interface gtk-theme "$gtkTheme" > /dev/null 2>&1;
    
    gearyConfigDir="";
    if [[ "$(flatpak list | grep org.gnome.Geary)" != "" ]]; then
        gearyConfigDir="$HOME/.var/app/org.gnome.Geary/config/geary";
    elif [[ "$(command -v geary)" != "" ]]; then
        gearyConfigDir="$HOME/.config/geary";
    fi
    
    if [[ "$gearyConfigDir" != "" ]]; then
        if [[ "$gearyDarkModeCss" != "" ]]; then
            mkdir -p "$gearyConfigDir";
            echo "$gearyDarkModeCss" >> "$gearyConfigDir/user-style.css";
        else
            rm "$gearyConfigDir/user-style.css" > /dev/null 2>&1;
        fi
    fi
    
    clear;
    echo "Operation Complete";
    if [[ "$gearyConfigDir" != "" ]]; then
        echo "Geary's theme switch needs you to log out to take effect (if ran in background)";
    fi
    echo "";
done
