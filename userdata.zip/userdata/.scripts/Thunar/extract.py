# CALL SYNTAX: python3 "script name" "dir structure" "filepath1" "filepath2"...
# sys.argv[0] is the name of the script
# sys.argv[1] the dir structure: "inner"/"outer"
# sys.argv[2:] the filepaths

# Unar is used to handle everything except ".rar" files. Unrar handles ".rar" files exclusevly
    # When a password protected file is extracted with a wrong password, both modules create 0 bite files
    # This affects duplicate action and can mess things up.
    # That is why, each archive is extracted in a temp folder, and the temp folder is emptied after every extraction

#########################################################

import os, sys, re, subprocess

#########################################################
# GLOBALS

NUM_FILES = None
DIR_STRUCTURE = None
PARENT_FOLDER = None
TEMP_FOLDER = None
RM_TEMP_FOLDER_CONTENTS_COMMAND = None
MOVE_FILES_FROM_TEMP_COMMAND = None
RM_TEMP_FOLDER_COMMAND = None
FILE_PATHS_ARR = None
DUPE_ACTION = None
PASSWORD = None
BLOCK_EXTRACTION_TIME_PASSWORD_POPUPS = None
ERRORS = None

#########################################################
# RUN

def run():
    init()
    extraction_process()
    display_errors()
    
#########################################################
# MAIN

def init():
    global NUM_FILES, DIR_STRUCTURE, TEMP_FOLDER, RM_TEMP_FOLDER_CONTENTS_COMMAND, RM_TEMP_FOLDER_COMMAND, PARENT_FOLDER, FILE_PATHS_ARR, PASSWORD, BLOCK_EXTRACTION_TIME_PASSWORD_POPUPS, ERRORS
    
    NUM_FILES = len(sys.argv) - 2
    if NUM_FILES <= 0: input("Not enough arguments provided. Press Enter to exit."); quit()

    if sys.argv[1] == "inner" or sys.argv[1] == "outer": DIR_STRUCTURE = sys.argv[1]
    else: input("The dir structure argument is wrong. Press Enter to exit."); quit()

    PARENT_FOLDER = path_fixer(os.path.dirname(sys.argv[2]))
    if not os.access(PARENT_FOLDER, os.W_OK): input("Write permission missing. Press Enter to exit."); quit()

    TEMP_FOLDER = get_unused_path(f"{PARENT_FOLDER}/.tempExtract")
    os.system(f"mkdir \"{TEMP_FOLDER}\"")
    RM_TEMP_FOLDER_CONTENTS_COMMAND = f"rm -r \"{TEMP_FOLDER}/\"* > /dev/null 2>&1"
    RM_TEMP_FOLDER_COMMAND = f"rm -r \"{TEMP_FOLDER}\" > /dev/null 2>&1"

    move_command_generator()
    
    FILE_PATHS_ARR = []
    for filePath in sys.argv[2:]: FILE_PATHS_ARR.append(path_fixer(filePath))

    PASSWORD = "test"
    BLOCK_EXTRACTION_TIME_PASSWORD_POPUPS = False
    ERRORS = ""

def extraction_process():
    global ERRORS
    fileCounter = 1
    for filePath in FILE_PATHS_ARR:
        if not os.path.exists(filePath): ERRORS += f"{os.path.basename(filePath)}:\nFile removed before extraction\n\n"; continue
        if re.match(r"^.+\.part[0-9]+\.rar$", filePath) and not filePath.endswith("part1.rar"): continue
        single_archive_handler(filePath, fileCounter)
        fileCounter += 1   
    os.system(RM_TEMP_FOLDER_COMMAND)

def display_errors():
    global ERRORS
    os.system("clear")
    ERRORS = ERRORS.strip()
    if ERRORS == "": return
    print(f"OPERATION COMPLETE WITH ERRORS:\n\n{ERRORS}\n\n")
    input("Press enter to close")

#########################################################
# EXTRACTING SINGLE ARCHIVE

def single_archive_handler(filePath, fileCounter):
    global ERRORS

    while 1==1:
        os.system(RM_TEMP_FOLDER_CONTENTS_COMMAND)
        os.system("clear")
        print(f"EXTRACTING: {fileCounter}/{NUM_FILES}")
        
        extractCommand = extract_command_generator(filePath)
        extractCommandOutput = subprocess.run(extractCommand, shell=True, text=True, capture_output=True)
        
        errMsg = extractCommandOutput.stderr.strip()
        if errMsg:
            if is_wrong_pass_msg(errMsg):
                os.system(RM_TEMP_FOLDER_CONTENTS_COMMAND)
                errMsg = "Wrong password. Archive skipped."
                if get_wrong_pass_user_input(filePath) == "new pass entered": continue
            ERRORS += f"{os.path.basename(filePath)}:\n{errMsg}\n\n"

        if dupes_found(TEMP_FOLDER) and not DUPE_ACTION:
            dupe_action_user_input()
            move_command_generator()

        os.system(MOVE_FILES_FROM_TEMP_COMMAND)
        break

#########################################################
# COMMAND GENERATORS

def extract_command_generator(filePath):
    command = ""
    fileExt = filePath.split(".")[-1]
    isRar = True if fileExt == "rar" else False
    outputDir = get_outer_output_folder_unrar(filePath) if isRar and DIR_STRUCTURE == "outer" else TEMP_FOLDER

    if isRar:
        command = f"unrar x -op\"{outputDir}\" -p\"{PASSWORD}\" \"{filePath}\" > /dev/null" # unrar doesnt have a quite mode (I just need errors)
    else:
        unarInnerOuterFlag = "-force-directory" if DIR_STRUCTURE == "outer" else "-no-directory"
        command = f"unar -quiet -output-directory \"{outputDir}\" {unarInnerOuterFlag} -password \"{PASSWORD}\" \"{filePath}\""

    return command

def move_command_generator():
    global MOVE_FILES_FROM_TEMP_COMMAND

    command = "cp --recursive --link"
    if DUPE_ACTION == "skip": command += " --no-clobber"
    elif DUPE_ACTION == "rename": command += " --backup=numbered"
    elif DUPE_ACTION == "overwrite": command += " --force"
    command += f" \"{TEMP_FOLDER}/\"* \"{PARENT_FOLDER}/\" > /dev/null 2>&1"
    MOVE_FILES_FROM_TEMP_COMMAND = command
        
#########################################################
# USER INPUTS

def dupe_action_user_input():
    global DUPE_ACTION
    os.system("clear")
    while 1==1:
        userInput = input("DUPLICATES FOUND (this will apply to future duplicates):\n(1) Skip [default]\n(2) Rename\n(3) Overwrite\n").strip()
        os.system("clear")
        if userInput == "1" or userInput == "": DUPE_ACTION = "skip"; break
        elif userInput == "2": DUPE_ACTION = "rename"; break
        elif userInput == "3": DUPE_ACTION = "overwrite"; break
        else: print("*** Invalid input. Try again.")

def get_wrong_pass_user_input(filePath):
    global BLOCK_EXTRACTION_TIME_PASSWORD_POPUPS

    if BLOCK_EXTRACTION_TIME_PASSWORD_POPUPS: return "skip"

    os.system("clear")

    while 1==1:
        userInput = input(f"PASSWORD NEEDED FOR \"{os.path.basename(filePath)}\"\n(1) Enter password [default]\n(2) Skip archive\n(3) Skip all remaining\n").strip()
        os.system("clear")
        if userInput == "1" or userInput == "": password_user_input(); return "new pass entered"
        elif userInput == "2": return "skip"
        elif userInput == "3": BLOCK_EXTRACTION_TIME_PASSWORD_POPUPS = True; return "skip"
        else: print("*** Invalid input. Try again.")

def password_user_input():
    global PASSWORD
    os.system("clear")
    userInput = input("ENTER PASSWORD TO USE (or leave empty)\n").strip()
    os.system("clear")
    if userInput != "": PASSWORD = userInput

#########################################################
# GENERAL FUNCTIONS

# if the path provided ends with "/", it removes it
def path_fixer(filePath):
    if filePath.endswith("/"): filePath = filePath[:-1]
    return filePath

# given the path of a file/folder, it returns one that doesn't exist (numbered if original one exists)
def get_unused_path(filePath):
    if not os.path.exists(filePath): return filePath
    counter = 1
    while 1==1:
        newFilePath = f"{filePath} ({counter})"
        if not os.path.exists(newFilePath): return newFilePath
        counter += 1

# with unrar (for rar files), the outer functionality needs to be implemented by setting the output folder (to one with the archive's name)
def get_outer_output_folder_unrar(filePath):
    fileNameWoExt = os.path.basename(filePath)[:-4]
    if re.match(r"^.+\.part[0-9]+$", fileNameWoExt): fileNameWoExt = ".".join(fileNameWoExt.split(".")[:-1]) # remove .part
    return f"{TEMP_FOLDER}/{fileNameWoExt}"

# unrar and unar have different error messages, but with both, the first line of the error output contains "wrong password"
def is_wrong_pass_msg(errMsg):
    return True if "wrong password" in errMsg.split("\n")[0].strip() else False

# recursivly find duplicates (temp vs orig parent folder). Call using the TEMP FOLDER variable
def dupes_found(folderPath):
    dupes = False
    itemsInCurTempFolderArr = os.listdir(folderPath)
    for itemName in itemsInCurTempFolderArr:
        itemPath = f"{folderPath}/{itemName}"
        itemPathInParent = itemPath.replace(f"/{os.path.basename(TEMP_FOLDER)}", "")
        if os.path.isfile(itemPath) and os.path.exists(itemPathInParent): dupes = True
        elif os.path.isdir(itemPath): dupes = dupes_found(itemPath)
        if dupes == True: break
    return dupes
    
run()
