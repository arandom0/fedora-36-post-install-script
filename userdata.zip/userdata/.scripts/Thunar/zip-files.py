# CALL SYNTAX: python3 "script name" "filepath1" "filename2"...
# sys.argv[0] is the name of the script
# sys.argv[1:] the filenames

# The "zip" module requires you to use the parent directory and only include filenames for the zips you want to extract

#########################################################

import os, sys, re, subprocess

#########################################################

NUM_FILES = None
FILE_NAMES_ARR = None
BASE_DIR = None
ZIP_OUTPUT_METHOD = None
SINGLE_ZIP_NAME_TEMP_WO_EXT = None # This is needed when doing a single zip. It's temp because it may change when dupes are scanned.
PASSWORD = None
DUPE_ACTION = None
FILENAMES_DICT = None # {"zipname1":"filename", "zipname2":'"filename1" "filename2"' ...}
ERRORS = None

#########################################################

def run():
    init()
    zip_files()
    if not ERRORS: return
    os.system("clear")
    print(f"OPERATION COMPLETE WITH ERRORS:\n\n{ERRORS}\n\n")
    input("Press any key and click enter to close")

#########################################################

def init():
    global NUM_FILES, FILE_NAMES_ARR, BASE_DIR, ZIP_OUTPUT_METHOD, SINGLE_ZIP_NAME_TEMP_WO_EXT, PASSWORD, FILENAMES_DICT, DUPE_ACTION, ERRORS

    # Validation 1 + Set 1
    NUM_FILES = len(sys.argv) - 1
    if NUM_FILES <= 0: input("Not enough arguments provided. Press Enter to exit."); quit()

    # Validation 2 + Set 2 & 3
    FILE_NAMES_ARR = []
    fileParentDir = None
    for filePath in sys.argv[1:]:
        filePath = path_fixer(filePath)
        fileParentDirTemp = os.path.dirname(filePath)
        if not fileParentDir: fileParentDir = fileParentDirTemp # for the initial run
        if fileParentDirTemp != fileParentDir: input("Files provided have different parent folders. Press Enter to exit."); quit()
        fileParentDir = fileParentDirTemp
        if not BASE_DIR: BASE_DIR = fileParentDir
        FILE_NAMES_ARR.append(os.path.basename(filePath))
    
    # Validation 3
    if not os.access(BASE_DIR, os.W_OK): input("Write permission missing. Press Enter to exit."); quit()

    # Set 4
    ZIP_OUTPUT_METHOD = "single" if NUM_FILES == 1 else get_zip_output_method_user_input()

    # Set 5
    if ZIP_OUTPUT_METHOD == "single":
        SINGLE_ZIP_NAME_TEMP_WO_EXT = FILE_NAMES_ARR[0] if NUM_FILES == 1 else get_single_zip_name_user_input()

    # Set 6
    PASSWORD = get_zip_password_user_input()

    # Set 7 & 8
    FILENAMES_DICT = {}
    zipFilesWoExtArr = [SINGLE_ZIP_NAME_TEMP_WO_EXT] if SINGLE_ZIP_NAME_TEMP_WO_EXT else FILE_NAMES_ARR
    for fileName in zipFilesWoExtArr:
        zipName = f"{fileName}.zip"
        if os.path.exists(f"{BASE_DIR}/{zipName}"):
            if not DUPE_ACTION: DUPE_ACTION = get_dupe_action_user_input()
            if DUPE_ACTION == "skip": continue
            elif DUPE_ACTION == "replace": os.system(f"rm \"{BASE_DIR}/{zipName}\" > /dev/null 2>&1")
            else: zipName = get_unused_zip_name(fileName)
        if ZIP_OUTPUT_METHOD == "single": FILENAMES_DICT[zipName] = array_to_str_with_quotes_and_spaces(FILE_NAMES_ARR)
        else: FILENAMES_DICT[zipName] = f"\"{fileName}\""

    # Set 9
    ERRORS = ""

# -------------------------------------------------------
# HELPERS

# if the path provided ends with "/", it removes it
def path_fixer(filePath):
    if filePath.endswith("/"): filePath = filePath[:-1]
    return filePath

def get_zip_output_method_user_input():
    os.system("clear")
    while 1==1:
        userInput = input("PUT FILES:\n(1) In a single zip file [default]\n(2) Each in a separate zip\n").strip()
        os.system("clear")
        if userInput == "1" or userInput == "": return "single"
        elif userInput == "2": return "separate"
        else: print("*** Invalid input. Try again.")

def get_single_zip_name_user_input():
    os.system("clear")
    while 1==1:
        userInput = input("NAME OF ZIP FILE (no extension) (can't contain: <>:\"/\?):\n").strip()
        os.system("clear")
        if re.match(r"^.*(<|>|:|\"|\/|\\|\||\?).*$", userInput) or userInput == "": print("*** Invalid name. Try again.")
        else: return userInput

def get_zip_password_user_input():
    os.system("clear")
    userInput = input("ENTER PASSWORD TO USE (or leave empty)\n").strip()
    os.system("clear")
    return userInput

def get_dupe_action_user_input():
    os.system("clear")
    while 1==1:
        userInput = input("DUPLICATE ZIP/s FOUND. ACTION TO TAKE:\n(1) Skip [default]\n(2) Rename\n(3) Replace\n").strip()
        os.system("clear")
        if userInput == "1" or userInput == "": return "skip"
        elif userInput == "2": return "rename"
        elif userInput == "3": return "replace"
        else: print("*** Invalid input. Try again.")

def get_unused_zip_name(fileName):
    counter = 1
    while 1==1:
        newZipName = f"{fileName} ({counter}).zip"
        if not os.path.exists(f"{BASE_DIR}/{newZipName}"): return newZipName
        counter += 1

# ["one", "two"] => '"one" "two"'
# Used when adding multiple files in a single zip, to put them in the exact format needed for the zip command
def array_to_str_with_quotes_and_spaces(arr):
    outputStr = ""
    for item in arr: outputStr += f"\"{item}\" "
    return outputStr.strip()


#########################################################

def zip_files():
    global ERRORS

    os.chdir(BASE_DIR) # python equivalent of cd - needed for zip once again - output dir and filenames only
    zipFileCounter = 1
    for zipName in FILENAMES_DICT: # zipName = the key
        os.system("clear")
        #input(zipName)
        #input(FILENAMES_DICT[zipName])
        if ZIP_OUTPUT_METHOD == "single": print(f"Adding files to {zipName}...")
        elif ZIP_OUTPUT_METHOD == "separate": print(f"Working on zip file {zipFileCounter}/{len(FILENAMES_DICT)}...")
        
        commandOutput = None
        if PASSWORD: commandOutput = subprocess.run(f"zip -q -r --password \"{PASSWORD}\" \"{zipName}\" {FILENAMES_DICT[zipName]}", shell=True, text=True, capture_output=True)
        else: commandOutput = subprocess.run(f"zip -q -r \"{zipName}\" {FILENAMES_DICT[zipName]}", shell=True, text=True, capture_output=True)
        
        if commandOutput.stdout.strip(): ERRORS += f"*** {zipName}:\n{commandOutput.stdout}\n\n" # for some reason zip outputs errors in stdout instead of stderr
        zipFileCounter += 1

run()