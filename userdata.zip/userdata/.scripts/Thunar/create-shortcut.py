# Creates shortcuts to the selected file/s
# Syntact python3 "script name" "filepath1" "filepath2"...

# sys.argv[0] is the name of the script
# sys.argv[1:] the filepaths

#########################################################

import os, sys

#########################################################

def run():
    for filePath in sys.argv[1:]:
        shortcutPath = get_unused_path(f"{filePath} - Shortcut")
        # ln -s "$filePath" "$shortcutName"
        os.system(f"ln -s \"{filePath}\" \"{shortcutPath}\" > /dev/null 2>&1")
        
# given the path of a file/folder, it returns one that doesn't exist (numbered if original one exists)
def get_unused_path(filePath):
    if not os.path.exists(filePath): return filePath
    counter = 1
    while 1==1:
        newFilePath = f"{filePath} ({counter})"
        if not os.path.exists(newFilePath): return newFilePath
        counter += 1
        
        
run()
